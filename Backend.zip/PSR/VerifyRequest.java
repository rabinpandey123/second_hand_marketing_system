package com.Six_sem_project.PSR;

public class VerifyRequest {
    private String itemTitle;
private String PurchaseId;
    public String getPurchaseId() {
        return PurchaseId;
    }

    public void setPurchaseId() {
        this.PurchaseId=PurchaseId;
    }
    // Getters and Setters
    public String getItemTitle() {
        return itemTitle;
    }

    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }
}
