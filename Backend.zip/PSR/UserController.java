package com.Six_sem_project.PSR;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;

@RestController
@CrossOrigin(origins = {"http://localhost:3000", "http://127.0.0.1:3000"}, allowCredentials = "true")
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private OtpService otpService;

    // Step 1: Send OTP to email
    @PostMapping("/send-otp")
    public String sendOtp(@RequestParam String email) {
        if (userRepo.existsByEmail(email)) {
            return "exists";
        }
        otpService.sendOtpEmail(email);
        return "otp_sent";
    }

    // Step 2: Verify OTP and register user
    @PostMapping("/signup")
    public String registerUser(@RequestParam String fullname,
                               @RequestParam String username,
                               @RequestParam String email,
                               @RequestParam String password,
                               @RequestParam String otp) {
        if (!otpService.verifyOtp(email, otp)) {
            return "invalid_otp";
        }

        if (userRepo.existsByUsername(username) || userRepo.existsByEmail(email)) {
            return "exists";
        }

        User user = new User();
        user.setFullname(fullname);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password); // For production: hash this

        userRepo.save(user);
        otpService.clearOtp(email);
        return "success";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            HttpSession session) {
        System.out.println("Login attempt for email: " + email);
        User user = userRepo.findByEmailAndPassword(email, password);
        if (user != null) {
            session.setAttribute("loggedInUser", user.getUsername());
            System.out.println("Session ID after login: " + session.getId());
            System.out.println("Session attributes: " + Collections.list(session.getAttributeNames()));
            return "success";
        } else {
            return "invalid";
        }
    }
}
