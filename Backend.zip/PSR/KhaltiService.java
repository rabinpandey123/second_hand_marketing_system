//package com.Six_sem_project.PSR;
//
//import org.springframework.http.*;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.UUID;
//
//@Service
//public class KhaltiService {
//
//    private static final String KHALTI_PAYMENT_INIT_URL = "https://dev.khalti.com/api/v2/epayment/initiate/";
//    private static final String SECRET_KEY = "live_secret_key_68791341fdd94846a146f0457ff7b455";
//
//    private final RestTemplate restTemplate = new RestTemplate();
//
//    public Map<String, Object> initiatePayment(int item_price, String item_title) {
//        HttpHeaders headers = new HttpHeaders();
//        headers.set("Authorization", "Key " + SECRET_KEY);
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        Map<String, Object> payload = new HashMap<>();
//        String purchaseId = UUID.randomUUID().toString();
//        payload.put("return_url", "http://127.0.0.1:3000/c:/Users/ACER/Desktop/project/final/receipt.html?purchase_order_id=" + purchaseId);
//        System.out.println(purchaseId);
//        payload.put("website_url", "http://127.0.0.1:3000/c:/Users/ACER/Desktop/project/final/home.html");
//
//        payload.put("amount", item_price*100);  // amount in paisa (integer)
//        payload.put("purchase_order_id", purchaseId);
//        payload.put("purchase_order_name", item_title);
//        payload.put("customer_info", Map.of(
//                "name", "Second Hand Market",
//                "email", "secondhandmarket@gmail.com",
//                "phone", "9866297346"
//        ));
//
//        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
//
//        ResponseEntity<Map> response = restTemplate.postForEntity(KHALTI_PAYMENT_INIT_URL, request, Map.class);
//
//        return response.getBody();
//    }
//}

package com.Six_sem_project.PSR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class KhaltiService {

    //@Value("${khalti.secret.key}")
    private String khaltiSecretKey="live_secret_key_68791341fdd94846a146f0457ff7b455";



    @Autowired
    private RestTemplate restTemplate;

    private final ItemRepository itemRepository;
    private final PaymentRepository paymentRepository;

    private static final String VERIFY_URL = "https://dev.khalti.com/api/v2/epayment/lookup/";
    private static final String KHALTI_PAYMENT_INIT_URL = "https://dev.khalti.com/api/v2/epayment/initiate/";

    // Constructor injection (recommended)
    public KhaltiService(ItemRepository itemRepository, PaymentRepository paymentRepository) {
        this.restTemplate = new RestTemplate();
        this.itemRepository = itemRepository;
        this.paymentRepository = paymentRepository;
    }

    public Map<String, Object> initiatePayment(int itemPrice, String itemTitle) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Key " + khaltiSecretKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        String purchaseId = UUID.randomUUID().toString();

        Map<String, Object> payload = new HashMap<>();
        payload.put("return_url", "http://127.0.0.1:3000/c:/Users/ACER/Desktop/project/final/receipt.html?purchase_order_id=" + purchaseId);
        payload.put("website_url", "http://127.0.0.1:3000/home.html");
        payload.put("amount", itemPrice * 100);  // amount in paisa
        payload.put("purchase_order_id", purchaseId);
        payload.put("purchase_order_name", itemTitle);
        payload.put("customer_info", Map.of(
                "name", "Second Hand Market",
                "email", "secondhandmarket@gmail.com",
                "phone", "9866297346"
        ));

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(KHALTI_PAYMENT_INIT_URL, request, Map.class);
        System.out.println("Response body from Khalti: " + response.getBody());
        return response.getBody();
    }

    public boolean verifyPayment(String pidx,String item_titel) {
        System.out.println("verify ma aayao........");
        String lookupUrl = "https://a.khalti.com/api/v2/epayment/lookup/";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Key " + khaltiSecretKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> payload = Map.of("pidx", pidx);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(lookupUrl, request, Map.class);
System.out.println("statusvhvhgvghv vhvhgvgh vgh aayo"+response.getStatusCode());
        System.out.println("Body  vhvhgvgh vgh aayo"+response.getBody());
        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
            Map<String, Object> responseBody = response.getBody();

            String status = (String) responseBody.get("status");
            if ("Completed".equalsIgnoreCase(status)) {
               String pidx1 = (String) responseBody.get("transaction_id");
               int amountPaisa = (int) responseBody.get("total_amount");
                //BigDecimal amount = BigDecimal.valueOf(amountPaisa).divide(BigDecimal.valueOf(100));
                //String payerEmail = (String) ((Map<String, Object>) responseBody.get("user")).get("email");


//                Item item = itemRepository.findByTitle(item_titel);
//               //if (item == null || item.isSold()) return false;
//               //item.setSold(true);
//           itemRepository.save(item);

                Payment payment = new Payment();
                payment.setAmount(amountPaisa);
                payment.setKhaltiPaymentId(pidx);
                payment.setItem_name(item_titel);
                payment.setPaymentDate(LocalDateTime.now());
               // payment.setItem(item);
               // payment.setPurchaseId(product);
                payment.setPayerEmail("payerEmail");

                paymentRepository.save(payment);

                return true;
            }
        }

        return false;
    }

}