package com.Six_sem_project.PSR;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullname;
    private String username;
    private String email;
    private String password;

    // Getters and Setters

    public void setUsername(String username) {
        this.username = username;
    }

    public void setFullname(String fullname ){
        this.fullname=fullname;
    }
    public void setEmail(String email ){
        this.email=email;
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getFullname() {
        return fullname;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }
    public void  setPassword(String password){
        this.password=password;
    }
}

