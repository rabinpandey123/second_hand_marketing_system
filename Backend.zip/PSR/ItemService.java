package com.Six_sem_project.PSR;

import com.Six_sem_project.PSR.Item;
import com.Six_sem_project.PSR.ItemRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService {
    private ItemRepository itemRepository;
    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }


    public Item saveItem(Item item) {
        return itemRepository.save(item);
    }
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }


}
