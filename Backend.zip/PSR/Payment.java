package com.Six_sem_project.PSR;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String khaltiPaymentId;
    private int amount;
    private String item_name;

    private LocalDateTime paymentDate;

    @ManyToOne
    private Item item;

    private String payerEmail;
}
