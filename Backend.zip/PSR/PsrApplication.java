package com.Six_sem_project.PSR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PsrApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsrApplication.class, args);
	}

}
