package com.Six_sem_project.PSR;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpSession;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = {"http://localhost:3000", "http://127.0.0.1:3000"},
        allowCredentials = "true")
@RestController
@RequestMapping("/api/items")
public class ItemController {

    private final String uploadDir;
    private final ItemService itemService;

    @Autowired
    public ItemController(
            @Value("${file.upload-dir:./uploads/images}") String uploadDir,
            ItemService itemService) {
        this.uploadDir = uploadDir;
        this.itemService = itemService;
        initializeUploadDirectory();

//        @Value("${file.upload-dir:./uploads/images}") String uploadDir

    }

    private void initializeUploadDirectory() {
        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
                System.out.println("Created upload directory at: " + uploadPath);
            }
            System.out.println("Upload directory location: " + uploadPath);
        } catch (IOException e) {
            System.err.println("Failed to create upload directory: " + uploadDir);
            throw new RuntimeException("Failed to initialize upload directory", e);
        }
    }

    @PostMapping
    public ResponseEntity<?> handleSellForm(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String address,
            @RequestParam String wallet,
            @RequestParam String holder,
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam String category,
            @RequestParam String price,
            @RequestParam String contactMethod,
            @RequestParam("image") MultipartFile image,
            HttpSession session) throws IOException {

//        Object loggedInUser = session.getAttribute("loggedInUser");
//        if (loggedInUser == null) {
//            return ResponseEntity.status(401).body("Unauthorized");
//        }

        if (image.isEmpty()) {
            return ResponseEntity.badRequest().body("Image file cannot be empty");
        }

        String originalFilename = image.getOriginalFilename();
        String fileName = System.currentTimeMillis() + "_" + (originalFilename != null ? originalFilename.replace(" ", "_") : "image");

        Path destPath = Paths.get(uploadDir, fileName).toAbsolutePath().normalize();
        System.out.println("Saving to path: " + destPath.toString());

        try {
            image.transferTo(destPath);
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Failed to save uploaded file");
        }

        Item item = new Item();
        item.setName(name);
        item.setEmail(email);
        item.setPhone(phone);
        item.setAddress(address);
        item.setWallet(wallet);
        item.setHolder(holder);
        item.setTitle(title);
        item.setDescription(description);
        item.setCategory(category);
        item.setPrice(price);
        item.setContactMethod(contactMethod);
        item.setImageName(fileName);

        // Construct the URL for the image
        // Construct the URL for the image (accessible URL from the frontend)
        String imageUrl = "http://localhost:8080/uploads/images/" + fileName;
        item.setImageUrl(imageUrl);

        System.out.println("image ko url "+imageUrl);
        itemService.saveItem(item);

        return ResponseEntity.ok("Item saved successfully. Image URL: " + imageUrl);
    }
    @Data        // Lombok – or generate getters/setters manually
    static  public class InitiatePaymentRequest {
        private Long id;
        private String title;
        private int price;   // rupees
    }
    @Autowired
    private KhaltiService khaltiService;
    @PostMapping("/initiate-payment")
    //id, title, price
    public Map<String, Object> initiatePayment( @RequestBody InitiatePaymentRequest req) {
        System.out.println("hello aayo hai ya ");

System.out.println(req.getTitle());
        return khaltiService.initiatePayment(req.getPrice(),req.getTitle());
    }
//item ko  bhitra jana lai
    @Autowired
    private ItemRepository itemRepository;
    @GetMapping("/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable Long id) {
        Optional<Item> item = itemRepository.findById(id);
        return item.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Item> getAllItems() {
//        System.out.println(itemService.getAllItems());

        return itemService.getAllItems();

    }
}
