package com.Six_sem_project.PSR;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Six_sem_project.PSR.User;

public interface UserRepository extends JpaRepository<User, Long> {
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    User findByEmailAndPassword(String email, String password); // For login
}

