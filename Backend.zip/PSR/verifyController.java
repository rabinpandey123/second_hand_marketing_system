package com.Six_sem_project.PSR;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Map;


import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

    @RestController
    @CrossOrigin(origins = {"http://localhost:3000", "http://127.0.0.1:3000"},
            allowCredentials = "true")
    @RequestMapping("/api1/khalti1")
    @RequiredArgsConstructor
    public class verifyController {

        private final KhaltiService khaltiService;

        @PostMapping("/verify")
        public ResponseEntity<?> verifyPayment( @RequestParam String pidx,@RequestBody String item_title) {
            System.out.println("success aayo hai..........");
            System.out.println(item_title);
            boolean success = khaltiService.verifyPayment(
                    pidx,
item_title
//
//                    request.getItemId(),
//                    request.getPayerEmail()
            );
System.out.println("success aayo hai"+success);
            if (success) {
                return ResponseEntity.ok(Map.of("status", "success", "message", "Payment verified and item sold"));
            } else {
                return ResponseEntity.status(400).body(Map.of("status", "failed", "message", "Verification failed or item already sold"));
            }
        }
    }

    @Data
    class KhaltiVerifyRequest {
        private String token;
//        private BigDecimal amount;
//        private Long itemId;
//        private String payerEmail;
    }


//
//package com.Six_sem_project.PSR;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.*;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import java.math.BigDecimal;
//import java.time.LocalDateTime;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.UUID;
//
//@Service
//public class KhaltiService {
//
//    @Value("${khalti.secret.key}")
//    private String khaltiSecretKey="live_secret_key_68791341fdd94846a146f0457ff7b455";
//
//
//
//    @Autowired
//    private RestTemplate restTemplate;
//
//    private final ItemRepository itemRepository;
//    private final PaymentRepository paymentRepository;
//
//    private static final String VERIFY_URL = "https://khalti.com/api/v2/payment/verify/";
//    private static final String KHALTI_PAYMENT_INIT_URL = "https://dev.khalti.com/api/v2/epayment/initiate/";
//
//    // Constructor injection (recommended)
//    public KhaltiService(ItemRepository itemRepository, PaymentRepository paymentRepository) {
//        this.restTemplate = new RestTemplate();
//        this.itemRepository = itemRepository;
//        this.paymentRepository = paymentRepository;
//    }
//
//    public Map<String, Object> initiatePayment(int itemPrice, String itemTitle) {
//        HttpHeaders headers = new HttpHeaders();
//        headers.set("Authorization", "Key " + khaltiSecretKey);
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        String purchaseId = UUID.randomUUID().toString();
//
//        Map<String, Object> payload = new HashMap<>();
//        payload.put("return_url", "http://127.0.0.1:3000/receipt.html?purchase_order_id=" + purchaseId);
//        payload.put("website_url", "http://127.0.0.1:3000/home.html");
//        payload.put("amount", itemPrice * 100);  // amount in paisa
//        payload.put("purchase_order_id", purchaseId);
//        payload.put("purchase_order_name", itemTitle);
//        payload.put("customer_info", Map.of(
//                "name", "Second Hand Market",
//                "email", "secondhandmarket@gmail.com",
//                "phone", "9866297346"
//        ));
//
//        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
//
//        ResponseEntity<Map> response = restTemplate.postForEntity(KHALTI_PAYMENT_INIT_URL, request, Map.class);
//
//        return response.getBody();
//    }
//
//    public boolean verifyPayment(String token, BigDecimal amount, Long itemId, String payerEmail) {
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.set("Authorization", "Key " + khaltiSecretKey);
//
//        Map<String, Object> payload = Map.of(
//                "token", token,
//                "amount", amount.multiply(BigDecimal.valueOf(100)).intValue() // paisa
//        );
//
//        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
//
//        ResponseEntity<Map> response = restTemplate.postForEntity(VERIFY_URL, request, Map.class);
//
//        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
//            // Payment verified successfully
//
//            Item item = itemRepository.findById(itemId).orElse(null);
//            if (item == null) return false;
//
//            if (item.isSold()) {
//                // Already sold
//                return false;
//            }
//
//            item.setSold(true);
//            itemRepository.save(item);
//
//            Payment payment = new Payment();
//            payment.setAmount(amount);
//            payment.setKhaltiPaymentId(token);
//            payment.setPaymentDate(LocalDateTime.now());
//            payment.setItem(item);
//            payment.setPayerEmail(payerEmail);
//
//            paymentRepository.save(payment);
//
//            return true;
//        }
//
//        return false;
//    }
//}
//
